# dictcompare
 A python3 utility to compare nested dictionaries to any level.
